LibreAim Custom Edition 2026

Szenarien:
Moving Targets 60s
Random Targets 60s
Tracking 60s
Horizontal Target 60s
Horizontal Target 90s

Installation:
Szenarien in den LibreAim-Ordner custom_resources/scenarios kopieren.
